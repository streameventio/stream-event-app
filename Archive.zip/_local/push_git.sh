git add -A
git commit -m "$1"
git push https://github.com/streameventio/stream-event-app.git master
