git pull https://github.com/streameventio/stream-event-app.git master
