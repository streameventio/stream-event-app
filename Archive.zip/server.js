const express = require('express');
const postRouter = require('./routes/postRouter');
const userRouter = require('./routes/userRouter');

const app = express();
app.set('view engine', 'ejs');

// app.use(express.static(__dirname + "/static"));

app.use(express.static('static'));

app.get('/', function(req, res) {
  res.render("pages/index", {});
});

app.get('/about', function(req, res) {
  res.render("pages/about", {});
});

app.use(postRouter);
app.use(userRouter);

module.exports = app;