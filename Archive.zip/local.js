const app = require('./server');
// run the server locally
app.listen(3000, () => console.log('Server listening at http://localhost:3000'));